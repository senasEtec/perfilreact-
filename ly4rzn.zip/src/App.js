function MyButton() {

  return (
  
  <button>
  
  I'm a button
  
  </button>
  
  );
  
  }
  
   
  
  export default function MyApp() {
  
  return (
  
  <div>
  
  <h1>Gustavo Bruno Da Costa</h1>
  
  <p>Tenho 16 anos;</p>
  
  <p>Estudo na Etec Polivalente e no Senai em Americana (SP), cursnado Desenvolvimento de Sistemas;</p>
  
  <p>Nasci na cidade de Santa Barbara Do Oeste (SP); </p>
  
  <p>Gosto de esportes, músicas, livros, filmes, séries,carros, motos, dentre outras coisas;</p>

  </div>
  
  );
  
  }
